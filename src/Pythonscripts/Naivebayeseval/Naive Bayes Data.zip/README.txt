This zip contains 1 folder, Naive Bayes Data. which in turn contains 2 folders.

Naive Bayes Data
	processedtweets
		bands
		solo_artists
	unprocessedtweets
		bands
		solo_artists

The bands and solo_artists folders contains files like the following:
0StemmedGreenRiverOrdinance.txt

This file is band no. 0 in our database, it's name on twitter is GreenRiverOrdinance and the file is stemmed. The fact that the file is in the band folder indicates it has been handlabeled as a band.
The file contains a single line which is all tweets we have retrieved by that band. (200), in this case, they are stemmed.

If the filename was
0UnprocessedGreenRiverOrdinance.txt

It would be in the unprocessed tweets folder and the tweets would not have been stemmed.

The algorithm is run either on the processedtweets folder or the unprocessed tweets folder.